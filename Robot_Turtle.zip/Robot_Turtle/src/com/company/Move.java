package com.company;

public interface Move {
    public void play(Game game);
}

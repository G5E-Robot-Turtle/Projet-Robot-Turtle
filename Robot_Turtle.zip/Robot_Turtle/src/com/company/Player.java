package com.company;

import Card.Card;
import Card.Deck;

import java.util.List;

public class Player {
    private String color;
    private String direction;   //on pourra mettre char    N S O E (nord sud ...)
    private int score;
    private int passageDirection;
    private List<Card> program;
    private List<Card> handCard;
    private List<Block> blocks;
    private Deck discard;   //défausse
    private Deck deck;
    private String name;


    public String getName(){
        return name;
    }

    private static Card pickCardFromDeck(){
        //à compléter
        return null;     //à modifier
    }
}

package com.company;

public class BuildWallMove implements Move {
    public void play(Game game) {

    }
}

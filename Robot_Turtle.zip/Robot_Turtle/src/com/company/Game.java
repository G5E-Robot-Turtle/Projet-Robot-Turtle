package com.company;

import java.util.List;

public class Game {
    private List<Player> players;
}

package com.company;

public class Position {
    private int x;
    private int y;

}

package com.company;

public class Jewel {
    private boolean turtleIsArrived;
}

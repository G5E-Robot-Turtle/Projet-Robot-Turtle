package com.company;

public class StoneWall {
    private String description;
    private String name;

    public String getDescription() {
        return description;
    }

    public String getName(){
        return name;
    }
    public boolean isDestructible(){
        return false;
    }
}

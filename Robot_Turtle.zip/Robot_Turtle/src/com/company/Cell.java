package com.company;

public abstract class Cell {
    protected Player player;
    protected Block block;
    protected Jewel jewel;

}

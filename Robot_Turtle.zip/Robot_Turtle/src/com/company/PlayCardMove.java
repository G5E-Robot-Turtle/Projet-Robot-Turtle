package com.company;

public class PlayCardMove implements Move {

    @Override
    public void play(Game game) {

    }
}

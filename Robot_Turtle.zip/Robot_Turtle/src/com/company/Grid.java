package com.company;


public class Grid {
    private Cell[][] grid;

    public Cell[][] getGrid() {
        return grid;
    }
}

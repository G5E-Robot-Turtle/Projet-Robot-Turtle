package com.company;

public class IceWall extends Block {
    private String description;
    private String name;

    public String getDescription() {
        return description;
    }

    public String getName(){
        return name;
    }
    public boolean isDestructible(){
        return true;
    }
}

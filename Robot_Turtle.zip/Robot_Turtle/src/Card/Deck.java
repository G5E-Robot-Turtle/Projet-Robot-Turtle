package Card;

import java.util.Stack;

public class Deck {
    private Stack<Card> deck;

}
